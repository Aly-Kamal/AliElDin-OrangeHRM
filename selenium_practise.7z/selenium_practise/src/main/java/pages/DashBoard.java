package pages;

import org.openqa.selenium.WebDriver;

public class DashBoard extends BasePage{
    public DashBoard(WebDriver driver) {
        super(driver);
    }

    public String getTitle(){
        return getDriver().getTitle();
    }
}
