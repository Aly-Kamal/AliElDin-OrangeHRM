package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginScreen extends BasePage {

    private final By username = By.name("username");
    private final By password = By.name("password");
    private final By login = By.cssSelector("[type='submit']");

    public LoginScreen(WebDriver driver) {
        super(driver);
    }

    public LoginScreen navigateUrl(String url){
        driver.get(url);
        return this;
    }
    public LoginScreen enterUsername(String usernameValue){
        waitUntilElementPage(username);
        driver.findElement(username).sendKeys(usernameValue);
        return this;
    }

    public LoginScreen enterPassword(String passwordValue){
        waitUntilElementPage(password);
        driver.findElement(password).sendKeys(passwordValue);
        return this;
    }

    public DashBoard clickOnLogin(){
        driver.findElement(login).click();
        return new DashBoard(getDriver());
    }



}
