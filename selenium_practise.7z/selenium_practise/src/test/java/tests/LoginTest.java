package tests;

import org.checkerframework.checker.units.qual.C;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginScreen;

public class LoginTest {

    public WebDriver driver;

    final String orangeHRM = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
    @BeforeClass
    public void setWebDriver(){
        driver = new ChromeDriver();
    }

    @Test
    public void validateTheUserIsValid() {
        String actualTitle = "OrangeHRM";
        String expectedTitle = new LoginScreen(driver)
                                .navigateUrl(orangeHRM)
                                .enterUsername("Admin")
                                                      .enterPassword("admin123")
                                                      .clickOnLogin().getTitle();

        Assert.assertEquals(expectedTitle,actualTitle);
    }


    @AfterClass
    public void killWebDriver(){
        driver.close();
    }


}
